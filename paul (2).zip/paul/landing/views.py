from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout as auth_logout

def landing_page(request):
    return render(request, 'landing/index.html')

def logout_view(request):
    auth_logout(request)
    return redirect('/')
